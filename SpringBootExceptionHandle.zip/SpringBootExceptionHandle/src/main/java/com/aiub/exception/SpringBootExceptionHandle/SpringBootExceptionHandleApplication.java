package com.aiub.exception.SpringBootExceptionHandle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootExceptionHandleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExceptionHandleApplication.class, args);
	}

}
