package com.aiub.exception.SpringBootExceptionHandle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExceptionHandleApplicationTests {

	@Test
	void contextLoads() {
	}

}
